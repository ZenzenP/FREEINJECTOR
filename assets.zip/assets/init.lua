--名称
appname="ZENKAI FREE INJECTOR"
--版本号
appver="0.1"
--版本
appcode="1"
--SDK
appsdk="26"
--包名
packagename="com.error.inj"
--调试模式
debugmode=false
--应用权限
user_permission={
  "INTERNET",
  "SET_WALLPAPER",
  "SYSTEM_ALERT_WINDOW",
}
--跳过编译
skip_compilation={

}